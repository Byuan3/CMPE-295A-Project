def add_num(num1, num2):
    return num1 + num2


def sub_num(num1, num2):
    return num1 - num2
